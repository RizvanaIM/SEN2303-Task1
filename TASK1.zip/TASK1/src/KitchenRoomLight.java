public class KitchenRoomLight implements Light {
    private int brightness;
    private boolean isOn;

    @Override
    public void on() {
        isOn = true;
        brightness = 100; // Full brightness
        System.out.println("Kitchen Room Light is ON at full brightness");
    }

    @Override
    public void off() {
        isOn = false;
        brightness = 0;
        System.out.println("Kitchen Room Light is OFF.");
    }

    @Override
    public void dim(int level) {
        isOn = true;
        brightness = level;
        System.out.println("Kitchen Room Light dimmed to " + brightness + "%");
    }

    @Override
    public int getBrightness() {
        return brightness;
    }

    @Override
    public String getState() {
        return isOn ? "ON" : "OFF";
    }
}
