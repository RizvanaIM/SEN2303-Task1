public class Main {
    public static void main(String[] args) {
        // Create instances of Light
        Light kitchenLight = new KitchenRoomLight();
        Light livingRoomLight = new LivingRoomLight();

        // Create command objects for the kitchen light
        Command kitchenLightOn = new LightOnCommand(kitchenLight);
        Command kitchenLightOff = new LightOffCommand(kitchenLight);
        Command kitchenLightDim50 = new LightDimCommand(kitchenLight, 50);
        Command kitchenLightDim100 = new LightDimCommand(kitchenLight, 100);

        // Create command objects for the living room light
        Command livingRoomLightOn = new LightOnCommand(livingRoomLight);
        Command livingRoomLightOff = new LightOffCommand(livingRoomLight);
        Command livingRoomLightDim30 = new LightDimCommand(livingRoomLight, 30);
        Command livingRoomLightDim100 = new LightDimCommand(livingRoomLight, 100);

        // Create a remote control instance
        RemoteControl remote = new RemoteControl();

        // Set commands for different slots
        remote.setCommand(0, kitchenLightOn, kitchenLightOff);
        remote.setCommand(1, livingRoomLightOn, livingRoomLightOff);
        remote.setCommand(2, kitchenLightDim50, kitchenLightDim100);
        remote.setCommand(3, livingRoomLightDim30, livingRoomLightDim100);

        // Test kitchen light commands
        System.out.println("Testing Kitchen Light Commands:");
        remote.onButtonWasPressed(0);    // Turn on kitchen light
        remote.offButtonWasPressed(0);   // Turn off kitchen light
        remote.onButtonWasPressed(0);    // Turn on kitchen light

        // Test living room light commands
        System.out.println("\nTesting Living Room Light Commands:");
        remote.onButtonWasPressed(1);    // Turn on living room light
        remote.offButtonWasPressed(1);   // Turn off living room light
        remote.onButtonWasPressed(1);    // Turn on living room light

        // Test dim commands
        System.out.println("\nTesting Dim Commands:");
        remote.onButtonWasPressed(2);    // Turn on kitchen light
        kitchenLightDim50.execute();     // Dim kitchen light to 50%
        kitchenLightDim100.execute();    // Dim kitchen light to 100%

        remote.onButtonWasPressed(3);    // Turn on living room light
        livingRoomLightDim30.execute();  // Dim living room light to 30%
        livingRoomLightDim100.execute(); // Dim living room light to 100%
    }
}
